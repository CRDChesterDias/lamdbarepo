variable "aws_region" {
  type        = string
  description = "AWS region for Image Builder resources"
  default     = "us-east-1"
}

variable "project_name" {
  type        = string
  description = "Prefix for all resources"
  default     = "golden-ami"
}

variable "vpc_id" {
  type        = string
  description = "VPC ID used by the Image Builder build instance"
}

variable "subnet_id" {
  type        = string
  description = "Subnet ID used by the Image Builder build instance"
}

variable "security_group_id" {
  type        = string
  description = "Security group attached to the Image Builder build instance"
}

variable "instance_profile_name" {
  type        = string
  description = "IAM instance profile name for the Image Builder build instance"
}

variable "base_ami_id" {
  type        = string
  description = "Trusted base AMI ID used as the parent image"
}

variable "target_account_ids" {
  type        = list(string)
  description = "AWS account IDs that should be allowed to launch the resulting AMI"
  default     = []
}
