# Golden AMI with Terraform + EC2 Image Builder

This project creates an AWS EC2 Image Builder pipeline for a Linux golden AMI.

## Files

- `versions.tf` - Terraform and provider versions
- `variables.tf` - Input variables
- `main.tf` - Image Builder resources
- `outputs.tf` - Outputs
- `terraform.tfvars.example` - Example variable values
- `components/baseline-linux.yml` - Build and validation steps for the AMI

## Usage

```bash
terraform init
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars with your values
terraform plan
terraform apply
```

## Notes

- The EC2 Image Builder instance profile must already exist.
- The base AMI must be a trusted image for your OS standard.
- The sample component updates the OS, installs baseline packages, and validates package availability.
