aws_region            = "us-east-1"
project_name          = "golden-ami-linux"
vpc_id                = "vpc-001b426bb186a6026"
subnet_id             = "subnet-0d0054bd04c0ba5a2"
security_group_id     = "sg-04511373f4da61494"
instance_profile_name = "mainrole"
base_ami_id           = "ami-0ec10929233384c7f"
target_account_ids    = ["498628473696"]


