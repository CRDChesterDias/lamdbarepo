output "image_pipeline_arn" {
  description = "ARN of the Image Builder pipeline"
  value       = aws_imagebuilder_image_pipeline.golden_pipeline.arn
}

output "image_recipe_arn" {
  description = "ARN of the Image Builder recipe"
  value       = aws_imagebuilder_image_recipe.golden_recipe.arn
}

output "imagebuilder_logs_bucket" {
  description = "S3 bucket that stores Image Builder logs"
  value       = aws_s3_bucket.imagebuilder_logs.id
}
