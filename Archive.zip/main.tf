data "aws_caller_identity" "current" {}

### Code for building S3 bucket for log capture
resource "aws_s3_bucket" "imagebuilder_logs" {
  bucket = "${var.project_name}-${data.aws_caller_identity.current.account_id}-${var.aws_region}-logs"

  tags = {
    Name    = "${var.project_name}-logs"
    Project = var.project_name
  }
}

### Code for building S3 bucket versioning enable

resource "aws_s3_bucket_versioning" "imagebuilder_logs" {
  bucket = aws_s3_bucket.imagebuilder_logs.id

  versioning_configuration {
    status = "Enabled"
  }
}

### Code for building S3 bucket server side encryption

resource "aws_s3_bucket_server_side_encryption_configuration" "imagebuilder_logs" {
  bucket = aws_s3_bucket.imagebuilder_logs.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# defining image builder baseline version and calling base scripts
resource "aws_imagebuilder_component" "baseline_windows" {
  name     = "${var.project_name}-baseline-windows"
  platform = "Windows"
  version  = "1.0.0"
  data     = file("${path.module}/components/baseline-windows.yml")

  tags = {
    Project = var.project_name
  }
}

# Recipe for building the AMI. Encryption is disabled to allow image encryption during deployment
resource "aws_imagebuilder_image_recipe" "golden_recipe" {
  name         = "${var.project_name}-recipe"
  version      = "1.0.0"
  parent_image = var.base_ami_id

  block_device_mapping {
    device_name = "/dev/sda1"

    ebs {
      delete_on_termination = true
      volume_size           = 30
      volume_type           = "gp3"
      encrypted             = false
    }
  }

  # this bit takes care of updates on the ami
  component {
    component_arn = "arn:aws:imagebuilder:${var.aws_region}:aws:component/update-windows/x.x.x"
  }

  component {
    component_arn = aws_imagebuilder_component.baseline_windows.arn
  }
  

  tags = {
    Project = var.project_name
  }
}

# This bit controls image builder settings like linking to logs and instance used to build ami
resource "aws_imagebuilder_infrastructure_configuration" "golden_infra" {
  name                          = "${var.project_name}-infra"
  instance_profile_name         = var.instance_profile_name
  instance_types                = ["t3.large"]
  subnet_id                     = var.subnet_id
  security_group_ids            = [var.security_group_id]
  terminate_instance_on_failure = true

  logging {
    s3_logs {
      s3_bucket_name = aws_s3_bucket.imagebuilder_logs.id
      s3_key_prefix  = "imagebuilder"
    }
  }

  resource_tags = {
    Project = var.project_name
  }

  tags = {
    Project = var.project_name
  }
}

# This bit manages the distribution accross accounts
resource "aws_imagebuilder_distribution_configuration" "golden_dist" {
  name = "${var.project_name}-distribution"

  distribution {
    region = var.aws_region

    ami_distribution_configuration {
      name = "${var.project_name}-{{ imagebuilder:buildDate }}"

      launch_permission {
        user_ids = var.target_account_ids
      }

      ami_tags = {
        Name        = var.project_name
        BuiltBy     = "EC2ImageBuilder"
        Environment = "shared"
      }
    }
  }

  tags = {
    Project = var.project_name
  }
}

# This bit manages the pipelines settings like how often it should run
resource "aws_imagebuilder_image_pipeline" "golden_pipeline" {
  name                             = "${var.project_name}-pipeline"
  image_recipe_arn                 = aws_imagebuilder_image_recipe.golden_recipe.arn
  infrastructure_configuration_arn = aws_imagebuilder_infrastructure_configuration.golden_infra.arn
  distribution_configuration_arn   = aws_imagebuilder_distribution_configuration.golden_dist.arn
  status                           = "ENABLED"

  image_tests_configuration {
    image_tests_enabled = true
    timeout_minutes     = 60
  }

  schedule {
    schedule_expression                = "cron(0 3 ? * SUN *)"
    pipeline_execution_start_condition = "EXPRESSION_MATCH_AND_DEPENDENCY_UPDATES_AVAILABLE"
  }

  tags = {
    Project = var.project_name
  }
}