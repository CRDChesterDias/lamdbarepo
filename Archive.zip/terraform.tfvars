aws_region            = "us-east-1"
project_name          = "golden-ami-windows"
vpc_id                = "vpc-02617d659ae4ed9c8"
subnet_id             = "subnet-0c7738164dfd64e3e"
security_group_id     = "sg-07b479618688675cc"
instance_profile_name = "mainrole"
base_ami_id           = "ami-05856bd26dd466893"
target_account_ids    = ["498628473696"]


